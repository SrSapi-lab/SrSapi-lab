a = float(input('Digite o valor em dolar: '))
r = a * 5.06
print('US${0} é R${1:.2f}'.format(a, r))