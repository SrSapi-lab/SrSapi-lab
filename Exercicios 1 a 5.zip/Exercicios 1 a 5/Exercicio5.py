a = float(input("Digite as horas de trebalho: "))
b = float(input("Digite o valor de horas trabalhadas: "))
c = float(input("Digite o percentual de desconto: "))
sb = a * b
td = (c / 100) * sb
sl = sb - td
print("O sua horas de trabalho são {0}".format(a))
print("O salário bruto é {0}, com o total de desconto de {1}, salárrio líquido é {2} ".format(sb, td, sl))