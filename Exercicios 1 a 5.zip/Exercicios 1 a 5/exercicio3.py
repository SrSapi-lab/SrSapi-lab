a = float(input("Digite um número: "))
b = float(input('Digite outro número: '))
c = a % b
print("O resto da divisão de {0} dividido por {1} é {2} ".format(a, b, c))