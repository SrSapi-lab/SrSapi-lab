a = float(input("Digite o seu gasto: "))
v = a - ((10 * 100 ) / 100)
print('O valor a ser pago é {0} com os 10% do garçom'.format(v))