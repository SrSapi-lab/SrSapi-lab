a = int(input("Digite as horas: "))
b = int(input('Digite os minutos: '))
m = a * 60
m1 = m + b
print("Em {0} horas e {1} minutos se passaram {2} minutos".format(a, b, m1))